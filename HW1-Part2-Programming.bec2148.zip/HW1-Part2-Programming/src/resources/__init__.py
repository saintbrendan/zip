from .baseresource import BaseResource
from .studentresource import StudentResource
